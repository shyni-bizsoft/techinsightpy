from django.apps import AppConfig


class HtmlPageConfig(AppConfig):
    name = 'html_page'
